# Español Latino Americano ULB

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/324  (NT)
STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/372  (OT)